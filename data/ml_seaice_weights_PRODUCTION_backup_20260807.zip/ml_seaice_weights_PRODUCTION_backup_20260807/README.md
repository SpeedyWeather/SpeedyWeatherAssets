# MLSeaIce production weights (backup, 2026-08-07)

These are the 5 weight directories currently wired into `MLSeaIce`'s default fields in
`SpeedyWeather.jl-main/SpeedyWeather/src/parameterizations/ml_seaice.jl` (the ones actually used
by the adopted online-coupling scripts, e.g. `run_20yr_t31_ml_full.jl` / `run_3yr_t63_ml_full.jl`).
Trained on the local 9-year (1980-1988) dataset, not the 40-year server run.

Each directory is a raw Float32-binary export of one trained PyTorch checkpoint (backbone weights,
heads, normalization stats, tau parameters) plus a `manifest.txt` describing each tensor's shape,
in the format the Julia `MLSeaIceModel` loader expects.

| Directory | Hemisphere | SIC band | Model type |
|---|---|---|---|
| `ml_seaice_weights_mono1000` | Arctic | mid (0.1-0.9) | RelaxationMoEClassifier (inc/dec heads) |
| `ml_seaice_weights_highsic_mono10` | Arctic | high (0.9-1.0) | RelaxationMoEClassifier (inc/dec heads) |
| `ml_seaice_weights_lowsic_changegate_mono100000_tau0005` | Arctic | low (0.0-0.1) | ChangeGateClassifier |
| `ml_seaice_weights_south_mid_mono1000` | Antarctic | mid (0.1-0.9) | RelaxationMoEClassifier (inc/dec heads) |
| `ml_seaice_weights_south_lowsic_changegate_mono10000` | Antarctic | low (0.0-0.1) | ChangeGateClassifier |

Antarctic has no dedicated high-SIC (0.9-1.0) expert -- the mid-band model extrapolates through
1.0 instead (found to outperform a dedicated high-SIC expert during earlier investigation).

The three Arctic experts are blended via a 3-way sigmoid soft gate (low/high gate centers 0.05/0.9,
width 0.025); the two Antarctic experts via a 2-way gate (low gate center 0.03, width 0.025).
